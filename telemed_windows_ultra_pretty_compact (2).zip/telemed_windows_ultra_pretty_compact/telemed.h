#ifndef TELEMED_H
#define TELEMED_H

#ifdef _MSC_VER
#define _CRT_SECURE_NO_WARNINGS
#endif

#include <stdint.h>
#include <time.h>

#define USERS_FILE        "users.dat"
#define DOCTORS_FILE      "doctors.dat"
#define PATIENTS_FILE     "patients.dat"
#define APPOINTMENTS_FILE "appointments.dat"

#define MAX_USERNAME 32
#define MAX_NAME     64
#define MAX_TEXT     128

typedef enum { ROLE_ADMIN=1, ROLE_DOCTOR=2, ROLE_PATIENT=3 } Role;
typedef enum { APPT_SCHEDULED=1, APPT_CANCELED=2, APPT_COMPLETED=3 } ApptStatus;

typedef struct {
    int id;
    char username[MAX_USERNAME];
    uint64_t pass_hash;
    int role;
    int profile_id;
} User;

typedef struct {
    int id;
    char name[MAX_NAME];
    char specialty[MAX_NAME];
    int work_start_min;
    int work_end_min;
    int slot_min;
} Doctor;

typedef struct {
    int id;
    char name[MAX_NAME];
    char contact[MAX_NAME];
} Patient;

typedef struct {
    int id;
    int doctor_id;
    int patient_id;
    time_t start_time;
    int duration_min;
    int status;
    char note[MAX_TEXT];
} Appointment;

typedef struct {
    User *users; int users_n;
    Doctor *doctors; int doctors_n;
    Patient *patients; int patients_n;
    Appointment *appts; int appts_n;

    int next_user_id;
    int next_doctor_id;
    int next_patient_id;
    int next_appt_id;
} DB;

void db_init(DB *db);
void db_load(DB *db);
void db_save(DB *db);
void db_free(DB *db);
void db_ensure_admin(DB *db);

void app_main_menu(DB *db);

#endif
