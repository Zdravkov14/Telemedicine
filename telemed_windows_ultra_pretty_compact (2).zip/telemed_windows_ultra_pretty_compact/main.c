#include "telemed.h"
#include <stdio.h>

#ifdef _WIN32
  #include <conio.h>
#endif

static void pause_before_close(void) {
#ifdef _WIN32
    puts("\nPress any key to exit...");
    (void)_getch();
#else
    puts("\nPress ENTER to exit...");
    (void)getchar();
#endif
}

int main(void) {
    DB db;
    db_init(&db);
    db_load(&db);
    db_ensure_admin(&db);

    app_main_menu(&db);

    db_save(&db);
    db_free(&db);

    pause_before_close();
    return 0;
}
