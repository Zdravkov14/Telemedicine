Telemedicine Scheduler (Windows console, ULTRA pretty)

What's new vs previous:
- Arrow-key menus (Up/Down/Enter, ESC to go back)
- Colors + reverse-highlight selection
- UTF-8 box drawing (when supported)
- Still works by double-clicking telemed.exe (pause on exit)

Build (PowerShell):
  cd "C:\Users\VikTDD\Downloads\telemed_windows_ultra_pretty"
  gcc -std=c11 -O2 -Wall -Wextra main.c telemed.c -o telemed.exe -mconsole
  .\telemed.exe

Build (CMD):
  cd /d "C:\Users\VikTDD\Downloads\telemed_windows_ultra_pretty"
  gcc -std=c11 -O2 -Wall -Wextra main.c telemed.c -o telemed.exe -mconsole
  telemed.exe

If you still get WinMain error:
  gcc -std=c11 -O2 -Wall -Wextra main.c telemed.c -o telemed.exe -Wl,--subsystem,console -Wl,-e,mainCRTStartup

Tip:
- Best look is in Windows Terminal (or modern PowerShell window).
- If the box characters look weird, your console might not support UTF-8.

Note: Source files are compacted (comments removed) to reduce size.
