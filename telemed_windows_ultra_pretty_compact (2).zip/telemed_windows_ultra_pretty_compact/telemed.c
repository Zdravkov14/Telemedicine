#include "telemed.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#ifdef _WIN32
  #include <windows.h>
  #include <conio.h>
#endif

static int g_vt = 0;
static int g_utf8 = 0;

static void ui_enable_vt_utf8(void) {
#ifdef _WIN32

    if (SetConsoleOutputCP(CP_UTF8)) g_utf8 = 1;
    if (SetConsoleCP(CP_UTF8)) g_utf8 = 1;

    HANDLE hOut = GetStdHandle(STD_OUTPUT_HANDLE);
    if (hOut == INVALID_HANDLE_VALUE) return;

    DWORD mode = 0;
    if (!GetConsoleMode(hOut, &mode)) return;
    mode |= ENABLE_VIRTUAL_TERMINAL_PROCESSING;
    if (SetConsoleMode(hOut, mode)) g_vt = 1;
#else
    g_vt = 1;
    g_utf8 = 1;
#endif
}

static void ui_cls(void) {
    if (g_vt) fputs("\x1b[2J\x1b[H", stdout);
#ifdef _WIN32
    else system("cls");
#else
    else system("clear");
#endif
}

static void ui_hide_cursor(int hide) {
    if (!g_vt) return;
    if (hide) fputs("\x1b[?25l", stdout);
    else fputs("\x1b[?25h", stdout);
}

static void ui_pause(void) {
#ifdef _WIN32
    fputs("\nPress any key to continue...", stdout);
    (void)_getch();
    fputc('\n', stdout);
#else
    fputs("\nPress ENTER to continue...", stdout);
    (void)getchar();
#endif
}

static const char* C_RESET(void){ return g_vt ? "\x1b[0m" : ""; }
static const char* C_BOLD(void){ return g_vt ? "\x1b[1m" : ""; }
static const char* C_DIM(void){ return g_vt ? "\x1b[2m" : ""; }
static const char* C_REV(void){ return g_vt ? "\x1b[7m" : ""; }
static const char* C_CYAN(void){ return g_vt ? "\x1b[36m" : ""; }
static const char* C_GREEN(void){ return g_vt ? "\x1b[32m" : ""; }
static const char* C_YELLOW(void){ return g_vt ? "\x1b[33m" : ""; }
static const char* C_RED(void){ return g_vt ? "\x1b[31m" : ""; }
static const char* C_GRAY(void){ return g_vt ? "\x1b[90m" : ""; }

static void ui_ok(const char *msg)   { printf("%s%s[OK]%s %s\n",   C_GREEN(), C_BOLD(), C_RESET(), msg); }
static void ui_warn(const char *msg) { printf("%s%s[!!]%s %s\n",   C_YELLOW(),C_BOLD(), C_RESET(), msg); }
static void ui_err(const char *msg)  { printf("%s%s[XX]%s %s\n",   C_RED(),   C_BOLD(), C_RESET(), msg); }

static int ui_menu(const char *title, const char *hint, const char **items, int count) {
    int sel = 0;
    ui_hide_cursor(1);

    for (;;) {
        ui_cls();

        time_t now = time(NULL);
        struct tm lt;
#ifdef _WIN32
        localtime_s(&lt, &now);
#else
        lt = *localtime(&now);
#endif
        char dt[64];
        strftime(dt, sizeof(dt), "%Y-%m-%d %H:%M", &lt);

        printf("%s%sTelemedicine Scheduler%s  %s%s%s\n", C_BOLD(), C_CYAN(), C_RESET(), C_GRAY(), dt, C_RESET());
        printf("%s%s%s\n", C_GRAY(), "────────────────────────────────────────────────────────", C_RESET());

        if (title && title[0]) printf("%s%s%s\n\n", C_BOLD(), title, C_RESET());
        if (hint && hint[0]) printf("%s%s%s\n\n", C_DIM(), hint, C_RESET());

        for (int i=0;i<count;i++) {
            if (i == sel) {
                if (g_vt) printf("  %s%s  %s  %s\n", C_REV(), C_BOLD(), items[i], C_RESET());
                else printf(" > %s\n", items[i]);
            } else {
                printf("    %s\n", items[i]);
            }
        }
        printf("\n%sUse ↑/↓ and ENTER. ESC = back.%s\n", C_DIM(), C_RESET());

#ifdef _WIN32
        int c = _getch();
        if (c == 0 || c == 224) {
            int k = _getch();
            if (k == 72) {
                sel = (sel - 1 + count) % count;
            } else if (k == 80) {
                sel = (sel + 1) % count;
            }
        } else if (c == 13) {
            ui_hide_cursor(0);
            return sel;
        } else if (c == 27) {
            ui_hide_cursor(0);
            return -1;
        }
#else

        ui_hide_cursor(0);
        return 0;
#endif
    }
}

static void trim_newline(char *s) {
    if (!s) return;
    size_t n = strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = '\0';
}

static void input_line(const char *prompt, char *buf, size_t cap) {
    if (prompt) printf("%s", prompt);
    if (!fgets(buf, (int)cap, stdin)) { buf[0] = '\0'; return; }
    trim_newline(buf);
}

static int is_blank(const char *s) {
    for (; s && *s; s++) if (!isspace((unsigned char)*s)) return 0;
    return 1;
}

static int input_int(const char *prompt, int minv, int maxv) {
    char line[64];
    for (;;) {
        input_line(prompt, line, sizeof(line));
        if (line[0] == '\0') continue;
        char *end = NULL;
        long v = strtol(line, &end, 10);
        if (end && *end == '\0' && v >= minv && v <= maxv) return (int)v;
        ui_warn("Invalid number. Try again.");
    }
}

static void str_copy0(char *dst, size_t cap, const char *src) {
    if (cap == 0) return;
    if (!src) { dst[0] = '\0'; return; }
#ifdef _MSC_VER
    strncpy_s(dst, cap, src, _TRUNCATE);
#else
    snprintf(dst, cap, "%s", src);
#endif
}

static uint64_t fnv1a64(const unsigned char *data, size_t len) {
    uint64_t hash = 1469598103934665603ULL;
    for (size_t i = 0; i < len; i++) {
        hash ^= (uint64_t)data[i];
        hash *= 1099511628211ULL;
    }
    return hash;
}
static uint64_t pass_hash(const char *username, const char *password) {
    char tmp[256];
    snprintf(tmp, sizeof(tmp), "%s:%s", username ? username : "", password ? password : "");
    return fnv1a64((const unsigned char*)tmp, strlen(tmp));
}

static int parse_hhmm(const char *s, int *out_minutes) {
    int h=-1, m=-1;
    if (!s || sscanf(s, "%d:%d", &h, &m) != 2) return 0;
    if (h < 0 || h > 23 || m < 0 || m > 59) return 0;
    *out_minutes = h*60 + m;
    return 1;
}
static int parse_yyyy_mm_dd(const char *s, int *Y, int *M, int *D) {
    int y=-1, m=-1, d=-1;
    if (!s || sscanf(s, "%d-%d-%d", &y, &m, &d) != 3) return 0;
    if (y < 1970 || m < 1 || m > 12 || d < 1 || d > 31) return 0;
    *Y = y; *M = m; *D = d;
    return 1;
}
static time_t make_time_local(int Y, int M, int D, int minutes_from_midnight) {
    struct tm t;
    memset(&t, 0, sizeof(t));
    t.tm_year = Y - 1900;
    t.tm_mon  = M - 1;
    t.tm_mday = D;
    t.tm_hour = minutes_from_midnight / 60;
    t.tm_min  = minutes_from_midnight % 60;
    t.tm_isdst = -1;
    return mktime(&t);
}
static void localtime_safe(const time_t *tt, struct tm *out) {
#ifdef _WIN32
    localtime_s(out, tt);
#else
    struct tm *p = localtime(tt);
    if (p) *out = *p; else memset(out, 0, sizeof(*out));
#endif
}
static void format_time(time_t tt, char *buf, size_t cap) {
    struct tm lt; localtime_safe(&tt, &lt);
    strftime(buf, cap, "%Y-%m-%d %H:%M", &lt);
}
static int same_day(time_t a, time_t b) {
    struct tm ta, tb;
    localtime_safe(&a, &ta);
    localtime_safe(&b, &tb);
    return ta.tm_year==tb.tm_year && ta.tm_mon==tb.tm_mon && ta.tm_mday==tb.tm_mday;
}

static void *xrealloc(void *p, size_t n) {
    void *q = realloc(p, n);
    if (!q) { fprintf(stderr, "Out of memory.\n"); exit(1); }
    return q;
}
static int max_id_users(const DB *db){ int mx=0; for(int i=0;i<db->users_n;i++) if(db->users[i].id>mx) mx=db->users[i].id; return mx; }
static int max_id_doctors(const DB *db){ int mx=0; for(int i=0;i<db->doctors_n;i++) if(db->doctors[i].id>mx) mx=db->doctors[i].id; return mx; }
static int max_id_patients(const DB *db){ int mx=0; for(int i=0;i<db->patients_n;i++) if(db->patients[i].id>mx) mx=db->patients[i].id; return mx; }
static int max_id_appts(const DB *db){ int mx=0; for(int i=0;i<db->appts_n;i++) if(db->appts[i].id>mx) mx=db->appts[i].id; return mx; }

static User* find_user_by_username(DB *db, const char *username) {
    for (int i=0;i<db->users_n;i++) if (strcmp(db->users[i].username, username) == 0) return &db->users[i];
    return NULL;
}
static Doctor* find_doctor_by_id(DB *db, int id) {
    for (int i=0;i<db->doctors_n;i++) if (db->doctors[i].id == id) return &db->doctors[i];
    return NULL;
}
static Patient* find_patient_by_id(DB *db, int id) {
    for (int i=0;i<db->patients_n;i++) if (db->patients[i].id == id) return &db->patients[i];
    return NULL;
}
static Appointment* find_appt_by_id(DB *db, int id) {
    for (int i=0;i<db->appts_n;i++) if (db->appts[i].id == id) return &db->appts[i];
    return NULL;
}

static void save_array(const char *path, const void *arr, int count, size_t elem_sz) {
    FILE *f = fopen(path, "wb");
    if (!f) { ui_err("Cannot write data file."); printf("File: %s\n", path); return; }
    fwrite(&count, sizeof(count), 1, f);
    if (count > 0) fwrite(arr, elem_sz, (size_t)count, f);
    fclose(f);
}
static int load_array(const char *path, void **out_arr, int *out_count, size_t elem_sz) {
    FILE *f = fopen(path, "rb");
    if (!f) { *out_arr=NULL; *out_count=0; return 0; }
    int count = 0;
    if (fread(&count, sizeof(count), 1, f) != 1) { fclose(f); return 0; }
    if (count < 0 || count > 1000000) { fclose(f); return 0; }
    void *arr = NULL;
    if (count > 0) {
        arr = malloc((size_t)count * elem_sz);
        if (!arr) { fclose(f); return 0; }
        if (fread(arr, elem_sz, (size_t)count, f) != (size_t)count) { free(arr); fclose(f); return 0; }
    }
    fclose(f);
    *out_arr = arr;
    *out_count = count;
    return 1;
}

void db_init(DB *db) {
    memset(db, 0, sizeof(*db));
    db->next_user_id = 1; db->next_doctor_id = 1; db->next_patient_id = 1; db->next_appt_id = 1;
}
void db_load(DB *db) {
    void *arr=NULL; int n=0;

    load_array(USERS_FILE, &arr, &n, sizeof(User));
    db->users=(User*)arr; db->users_n=n;

    load_array(DOCTORS_FILE, &arr, &n, sizeof(Doctor));
    db->doctors=(Doctor*)arr; db->doctors_n=n;

    load_array(PATIENTS_FILE, &arr, &n, sizeof(Patient));
    db->patients=(Patient*)arr; db->patients_n=n;

    load_array(APPOINTMENTS_FILE, &arr, &n, sizeof(Appointment));
    db->appts=(Appointment*)arr; db->appts_n=n;

    db->next_user_id = max_id_users(db)+1;
    db->next_doctor_id = max_id_doctors(db)+1;
    db->next_patient_id = max_id_patients(db)+1;
    db->next_appt_id = max_id_appts(db)+1;
}
void db_save(DB *db) {
    save_array(USERS_FILE, db->users, db->users_n, sizeof(User));
    save_array(DOCTORS_FILE, db->doctors, db->doctors_n, sizeof(Doctor));
    save_array(PATIENTS_FILE, db->patients, db->patients_n, sizeof(Patient));
    save_array(APPOINTMENTS_FILE, db->appts, db->appts_n, sizeof(Appointment));
}
void db_free(DB *db) {
    free(db->users); free(db->doctors); free(db->patients); free(db->appts);
    memset(db, 0, sizeof(*db));
}

static User* db_add_user(DB *db, const char *username, uint64_t ph, int role, int profile_id) {
    db->users = (User*)xrealloc(db->users, (size_t)(db->users_n+1) * sizeof(User));
    User *u = &db->users[db->users_n++];
    memset(u, 0, sizeof(*u));
    u->id = db->next_user_id++;
    str_copy0(u->username, sizeof(u->username), username);
    u->pass_hash = ph;
    u->role = role;
    u->profile_id = profile_id;
    return u;
}
static Doctor* db_add_doctor(DB *db, const char *name, const char *spec, int ws, int we, int slot) {
    db->doctors = (Doctor*)xrealloc(db->doctors, (size_t)(db->doctors_n+1) * sizeof(Doctor));
    Doctor *d = &db->doctors[db->doctors_n++];
    memset(d, 0, sizeof(*d));
    d->id = db->next_doctor_id++;
    str_copy0(d->name, sizeof(d->name), name);
    str_copy0(d->specialty, sizeof(d->specialty), spec);
    d->work_start_min = ws; d->work_end_min = we; d->slot_min = slot;
    return d;
}
static Patient* db_add_patient(DB *db, const char *name, const char *contact) {
    db->patients = (Patient*)xrealloc(db->patients, (size_t)(db->patients_n+1) * sizeof(Patient));
    Patient *p = &db->patients[db->patients_n++];
    memset(p, 0, sizeof(*p));
    p->id = db->next_patient_id++;
    str_copy0(p->name, sizeof(p->name), name);
    str_copy0(p->contact, sizeof(p->contact), contact);
    return p;
}
static Appointment* db_add_appt(DB *db, int doctor_id, int patient_id, time_t start, int dur, int status, const char *note) {
    db->appts = (Appointment*)xrealloc(db->appts, (size_t)(db->appts_n+1) * sizeof(Appointment));
    Appointment *a = &db->appts[db->appts_n++];
    memset(a, 0, sizeof(*a));
    a->id = db->next_appt_id++;
    a->doctor_id = doctor_id;
    a->patient_id = patient_id;
    a->start_time = start;
    a->duration_min = dur;
    a->status = status;
    if (note) str_copy0(a->note, sizeof(a->note), note);
    return a;
}

static int overlaps(time_t a_start, int a_dur_min, time_t b_start, int b_dur_min) {
    time_t a_end = a_start + (time_t)a_dur_min*60;
    time_t b_end = b_start + (time_t)b_dur_min*60;
    return (a_start < b_end) && (b_start < a_end);
}
static int doctor_has_conflict(DB *db, int doctor_id, time_t start, int dur_min, int ignore_appt_id) {
    for (int i=0;i<db->appts_n;i++) {
        Appointment *x = &db->appts[i];
        if (x->id == ignore_appt_id) continue;
        if (x->doctor_id != doctor_id) continue;
        if (x->status != APPT_SCHEDULED) continue;
        if (overlaps(start, dur_min, x->start_time, x->duration_min)) return 1;
    }
    return 0;
}

typedef struct { Appointment *a; } ApptPtr;
static int cmp_appt_ptr(const void *pa, const void *pb) {
    const ApptPtr *A=(const ApptPtr*)pa, *B=(const ApptPtr*)pb;
    if (A->a->start_time < B->a->start_time) return -1;
    if (A->a->start_time > B->a->start_time) return 1;
    return (A->a->id - B->a->id);
}

void db_ensure_admin(DB *db) {
    if (db->users_n != 0) return;
    const char *u="admin", *p="admin123";
    db_add_user(db, u, pass_hash(u,p), ROLE_ADMIN, 0);
    db_save(db);
    ui_warn("Created default admin account (first run).");
}

static User* ui_login(DB *db) {
    char username[MAX_USERNAME], password[64];
    input_line("Username: ", username, sizeof(username));
    input_line("Password: ", password, sizeof(password));

    User *u = find_user_by_username(db, username);
    if (!u) { ui_err("Login failed."); return NULL; }
    if (u->pass_hash != pass_hash(username, password)) { ui_err("Login failed."); return NULL; }
    ui_ok("Login successful.");
    return u;
}

static void ui_change_password(DB *db, User *me) {
    char oldp[64], n1[64], n2[64];
    input_line("Old password: ", oldp, sizeof(oldp));
    if (me->pass_hash != pass_hash(me->username, oldp)) { ui_err("Wrong password."); return; }
    input_line("New password: ", n1, sizeof(n1));
    input_line("Repeat new password: ", n2, sizeof(n2));
    if (strcmp(n1,n2)!=0 || is_blank(n1)) { ui_err("Passwords do not match (or empty)."); return; }
    me->pass_hash = pass_hash(me->username, n1);
    db_save(db);
    ui_ok("Password updated.");
}

static void ui_register_patient(DB *db) {
    char username[MAX_USERNAME], password[64];
    char name[MAX_NAME], contact[MAX_NAME];

    input_line("Choose username: ", username, sizeof(username));
    if (is_blank(username)) { ui_err("Username empty."); return; }
    if (find_user_by_username(db, username)) { ui_err("Username already exists."); return; }

    input_line("Choose password: ", password, sizeof(password));
    if (is_blank(password)) { ui_err("Password empty."); return; }

    input_line("Full name: ", name, sizeof(name));
    input_line("Contact (phone/email): ", contact, sizeof(contact));

    Patient *p = db_add_patient(db, name, contact);
    db_add_user(db, username, pass_hash(username, password), ROLE_PATIENT, p->id);
    db_save(db);
    ui_ok("Registered successfully.");
}

static void list_doctors(DB *db) {
    printf("\n%sDoctors%s\n", C_BOLD(), C_RESET());
    if (db->doctors_n==0) { puts("(no doctors yet)"); return; }
    for (int i=0;i<db->doctors_n;i++) {
        Doctor *d=&db->doctors[i];
        printf("  ID:%d  %s  %s(%s)%s  %02d:%02d-%02d:%02d  slot:%d\n",
               d->id, d->name, C_DIM(), d->specialty, C_RESET(),
               d->work_start_min/60, d->work_start_min%60,
               d->work_end_min/60, d->work_end_min%60,
               d->slot_min);
    }
}

static void search_doctors(DB *db) {
    char q[MAX_NAME];
    input_line("Search (name/specialty): ", q, sizeof(q));
    if (is_blank(q)) { ui_warn("Empty search."); return; }

    char ql[MAX_NAME]; snprintf(ql, sizeof(ql), "%s", q);
    for (char *p=ql; *p; p++) *p=(char)tolower((unsigned char)*p);

    printf("\n%sMatches%s\n", C_BOLD(), C_RESET());
    int found = 0;
    for (int i=0;i<db->doctors_n;i++) {
        Doctor *d=&db->doctors[i];
        char nl[MAX_NAME], sl[MAX_NAME];
        snprintf(nl, sizeof(nl), "%s", d->name);
        snprintf(sl, sizeof(sl), "%s", d->specialty);
        for (char *p=nl; *p; p++) *p=(char)tolower((unsigned char)*p);
        for (char *p=sl; *p; p++) *p=(char)tolower((unsigned char)*p);
        if (strstr(nl, ql) || strstr(sl, ql)) {
            printf("  ID:%d  %s (%s)\n", d->id, d->name, d->specialty);
            found = 1;
        }
    }
    if (!found) puts("(no matches)");
}

static void list_patient_appts(DB *db, int patient_id, int only_future) {
    time_t now=time(NULL);
    ApptPtr *tmp=NULL; int n=0;
    for (int i=0;i<db->appts_n;i++) {
        Appointment *a=&db->appts[i];
        if (a->patient_id != patient_id) continue;
        if (only_future && a->start_time < now) continue;
        tmp = (ApptPtr*)xrealloc(tmp, (size_t)(n+1)*sizeof(ApptPtr));
        tmp[n++].a = a;
    }
    qsort(tmp, (size_t)n, sizeof(ApptPtr), cmp_appt_ptr);

    printf("\n%sMy appointments%s\n", C_BOLD(), C_RESET());
    if (n==0) { puts("(none)"); free(tmp); return; }

    for (int i=0;i<n;i++) {
        Appointment *a=tmp[i].a;
        Doctor *d=find_doctor_by_id(db, a->doctor_id);
        char tbuf[32]; format_time(a->start_time, tbuf, sizeof(tbuf));
        const char *st = (a->status==APPT_SCHEDULED)?"SCHEDULED":(a->status==APPT_CANCELED)?"CANCELED":"COMPLETED";
        printf("  #%d  %s  Dr:%s  %dmin  %s  %s\n", a->id, tbuf, d?d->name:"?", a->duration_min, st, a->note);
    }
    free(tmp);
}

static void list_doctor_appts(DB *db, int doctor_id, int only_today) {
    time_t now=time(NULL);
    ApptPtr *tmp=NULL; int n=0;
    for (int i=0;i<db->appts_n;i++) {
        Appointment *a=&db->appts[i];
        if (a->doctor_id != doctor_id) continue;
        if (only_today && !same_day(a->start_time, now)) continue;
        tmp = (ApptPtr*)xrealloc(tmp, (size_t)(n+1)*sizeof(ApptPtr));
        tmp[n++].a = a;
    }
    qsort(tmp, (size_t)n, sizeof(ApptPtr), cmp_appt_ptr);

    printf("\n%sAppointments%s\n", C_BOLD(), C_RESET());
    if (n==0) { puts("(none)"); free(tmp); return; }

    for (int i=0;i<n;i++) {
        Appointment *a=tmp[i].a;
        Patient *p=find_patient_by_id(db, a->patient_id);
        char tbuf[32]; format_time(a->start_time, tbuf, sizeof(tbuf));
        const char *st = (a->status==APPT_SCHEDULED)?"SCHEDULED":(a->status==APPT_CANCELED)?"CANCELED":"COMPLETED";
        printf("  #%d  %s  Pt:%s  %dmin  %s  %s\n", a->id, tbuf, p?p->name:"?", a->duration_min, st, a->note);
    }
    free(tmp);
}

static void show_doctor_day_slots(DB *db, Doctor *doc, int Y, int M, int D, int only_free) {
    printf("\n%sSlots for %s (%04d-%02d-%02d)%s\n", C_BOLD(), doc->name, Y, M, D, C_RESET());
    int free_slots = 0;

    for (int m = doc->work_start_min; m + doc->slot_min <= doc->work_end_min; m += doc->slot_min) {
        time_t start = make_time_local(Y,M,D,m);
        int taken = doctor_has_conflict(db, doc->id, start, doc->slot_min, -1);
        if (only_free && taken) continue;

        printf("  %02d:%02d  %s%s%s\n",
               m/60, m%60,
               taken ? C_RED() : C_GREEN(),
               taken ? "TAKEN" : "FREE",
               C_RESET());
        if (!taken) free_slots++;
    }
    if (only_free) printf("%sFree slots:%s %d\n", C_DIM(), C_RESET(), free_slots);
}

static void patient_book(DB *db, int patient_id) {
    list_doctors(db);
    int doc_id = input_int("Doctor ID: ", 1, 1000000);
    Doctor *doc = find_doctor_by_id(db, doc_id);
    if (!doc) { ui_err("No such doctor."); return; }

    char date[32];
    input_line("Date (YYYY-MM-DD): ", date, sizeof(date));
    int Y,M,D;
    if (!parse_yyyy_mm_dd(date, &Y,&M,&D)) { ui_err("Invalid date."); return; }

    show_doctor_day_slots(db, doc, Y,M,D, 1);

    char hhmm[16];
    input_line("Start time (HH:MM): ", hhmm, sizeof(hhmm));
    int mm=0;
    if (!parse_hhmm(hhmm, &mm)) { ui_err("Invalid time."); return; }
    if (mm < doc->work_start_min || mm + doc->slot_min > doc->work_end_min) { ui_err("Outside work hours."); return; }

    time_t start = make_time_local(Y,M,D,mm);
    if (doctor_has_conflict(db, doc->id, start, doc->slot_min, -1)) { ui_err("Slot is taken."); return; }

    char note[MAX_TEXT];
    input_line("Note (optional): ", note, sizeof(note));

    db_add_appt(db, doc->id, patient_id, start, doc->slot_min, APPT_SCHEDULED, note);
    db_save(db);
    ui_ok("Booked.");
}

static void patient_cancel(DB *db, int patient_id) {
    list_patient_appts(db, patient_id, 0);
    int appt_id = input_int("Appointment ID to cancel: ", 1, 1000000);
    Appointment *a = find_appt_by_id(db, appt_id);
    if (!a || a->patient_id != patient_id) { ui_err("Not found."); return; }
    if (a->status != APPT_SCHEDULED) { ui_err("Cannot cancel (not scheduled)."); return; }
    a->status = APPT_CANCELED;
    db_save(db);
    ui_ok("Canceled.");
}

static void patient_reschedule(DB *db, int patient_id) {
    list_patient_appts(db, patient_id, 1);
    int appt_id = input_int("Appointment ID to reschedule: ", 1, 1000000);
    Appointment *a = find_appt_by_id(db, appt_id);
    if (!a || a->patient_id != patient_id) { ui_err("Not found."); return; }
    if (a->status != APPT_SCHEDULED) { ui_err("Only scheduled appointments can be rescheduled."); return; }

    Doctor *doc = find_doctor_by_id(db, a->doctor_id);
    if (!doc) { ui_err("Doctor missing."); return; }

    char date[32], hhmm[16];
    input_line("New date (YYYY-MM-DD): ", date, sizeof(date));
    int Y,M,D;
    if (!parse_yyyy_mm_dd(date, &Y,&M,&D)) { ui_err("Invalid date."); return; }

    show_doctor_day_slots(db, doc, Y,M,D, 1);

    input_line("New start time (HH:MM): ", hhmm, sizeof(hhmm));
    int mm=0;
    if (!parse_hhmm(hhmm, &mm)) { ui_err("Invalid time."); return; }
    if (mm < doc->work_start_min || mm + doc->slot_min > doc->work_end_min) { ui_err("Outside work hours."); return; }

    time_t new_start = make_time_local(Y,M,D,mm);
    if (doctor_has_conflict(db, doc->id, new_start, doc->slot_min, a->id)) { ui_err("Slot taken."); return; }

    a->start_time = new_start;
    a->duration_min = doc->slot_min;
    char note[MAX_TEXT];
    input_line("Update note (optional): ", note, sizeof(note));
    if (!is_blank(note)) str_copy0(a->note, sizeof(a->note), note);

    db_save(db);
    ui_ok("Rescheduled.");
}

static void doctor_list_patients(DB *db, int doctor_id) {
    int *ids=NULL; int n=0;
    for (int i=0;i<db->appts_n;i++) {
        Appointment *a=&db->appts[i];
        if (a->doctor_id != doctor_id) continue;
        if (a->status == APPT_CANCELED) continue;
        int pid=a->patient_id;
        int exists=0;
        for (int k=0;k<n;k++) if (ids[k]==pid) { exists=1; break; }
        if (!exists) { ids=(int*)xrealloc(ids, (size_t)(n+1)*sizeof(int)); ids[n++]=pid; }
    }
    printf("\n%sMy patients%s\n", C_BOLD(), C_RESET());
    if (n==0) { puts("(none)"); free(ids); return; }
    for (int i=0;i<n;i++) {
        Patient *p=find_patient_by_id(db, ids[i]);
        if (p) printf("  ID:%d  %s  %s\n", p->id, p->name, p->contact);
    }
    free(ids);
}

static void doctor_mark_status(DB *db, int doctor_id) {
    list_doctor_appts(db, doctor_id, 0);
    int appt_id = input_int("Appointment ID: ", 1, 1000000);
    Appointment *a=find_appt_by_id(db, appt_id);
    if (!a || a->doctor_id != doctor_id) { ui_err("Not found."); return; }

    printf("1) COMPLETED\n2) CANCELED\n");
    int ch = input_int("Choose: ", 1, 2);
    a->status = (ch==1) ? APPT_COMPLETED : APPT_CANCELED;

    char note[MAX_TEXT];
    input_line("Note (optional): ", note, sizeof(note));
    if (!is_blank(note)) str_copy0(a->note, sizeof(a->note), note);

    db_save(db);
    ui_ok("Updated.");
}

static void doctor_update_schedule(DB *db, int doctor_id) {
    Doctor *d=find_doctor_by_id(db, doctor_id);
    if (!d) { ui_err("Doctor profile missing."); return; }
    printf("Current: %02d:%02d-%02d:%02d | slot %d\n",
           d->work_start_min/60, d->work_start_min%60,
           d->work_end_min/60, d->work_end_min%60,
           d->slot_min);

    char ws_s[16], we_s[16];
    input_line("New work start (HH:MM): ", ws_s, sizeof(ws_s));
    input_line("New work end (HH:MM): ", we_s, sizeof(we_s));
    int ws=0,we=0;
    if (!parse_hhmm(ws_s, &ws) || !parse_hhmm(we_s, &we) || ws>=we) { ui_err("Invalid work hours."); return; }
    int slot = input_int("New slot minutes (10..180): ", 10, 180);

    d->work_start_min=ws; d->work_end_min=we; d->slot_min=slot;
    db_save(db);
    ui_ok("Schedule updated.");
}

static void admin_create_doctor(DB *db) {
    char username[MAX_USERNAME], password[64], name[MAX_NAME], spec[MAX_NAME], ws_s[16], we_s[16];

    input_line("Doctor username: ", username, sizeof(username));
    if (is_blank(username)) { ui_err("Username empty."); return; }
    if (find_user_by_username(db, username)) { ui_err("Username exists."); return; }

    input_line("Doctor password: ", password, sizeof(password));
    if (is_blank(password)) { ui_err("Password empty."); return; }

    input_line("Doctor full name: ", name, sizeof(name));
    input_line("Specialty: ", spec, sizeof(spec));

    input_line("Work start (HH:MM): ", ws_s, sizeof(ws_s));
    input_line("Work end (HH:MM): ", we_s, sizeof(we_s));
    int ws=0,we=0;
    if (!parse_hhmm(ws_s,&ws) || !parse_hhmm(we_s,&we) || ws>=we) { ui_err("Invalid hours."); return; }
    int slot = input_int("Slot minutes (10..180): ", 10, 180);

    Doctor *d=db_add_doctor(db, name, spec, ws, we, slot);
    db_add_user(db, username, pass_hash(username, password), ROLE_DOCTOR, d->id);

    db_save(db);
    ui_ok("Doctor created.");
    printf("DoctorID=%d\n", d->id);
}

static void admin_list_users(DB *db) {
    printf("\n%sUsers%s\n", C_BOLD(), C_RESET());
    if (db->users_n==0) { puts("(none)"); return; }
    for (int i=0;i<db->users_n;i++) {
        User *u=&db->users[i];
        const char *r = (u->role==ROLE_ADMIN)?"ADMIN":(u->role==ROLE_DOCTOR)?"DOCTOR":"PATIENT";
        printf("  ID:%d  %s  %s  profile_id=%d\n", u->id, u->username, r, u->profile_id);
    }
}

static void admin_list_appts(DB *db) {
    printf("\n%sAll appointments%s\n", C_BOLD(), C_RESET());
    if (db->appts_n==0) { puts("(none)"); return; }

    ApptPtr *tmp=(ApptPtr*)malloc((size_t)db->appts_n * sizeof(ApptPtr));
    int n=0;
    for (int i=0;i<db->appts_n;i++) tmp[n++].a=&db->appts[i];
    qsort(tmp, (size_t)n, sizeof(ApptPtr), cmp_appt_ptr);

    for (int i=0;i<n;i++) {
        Appointment *a=tmp[i].a;
        Doctor *d=find_doctor_by_id(db, a->doctor_id);
        Patient *p=find_patient_by_id(db, a->patient_id);
        char tbuf[32]; format_time(a->start_time, tbuf, sizeof(tbuf));
        const char *st = (a->status==APPT_SCHEDULED)?"SCHEDULED":(a->status==APPT_CANCELED)?"CANCELED":"COMPLETED";
        printf("  #%d  %s  Dr:%s  Pt:%s  %dmin  %s  %s\n", a->id, tbuf, d?d->name:"?", p?p->name:"?", a->duration_min, st, a->note);
    }
    free(tmp);
}

static void dashboard_patient(DB *db, User *me) {
    const char *items[] = {
        "List doctors",
        "Search doctors",
        "View doctor FREE slots (day)",
        "Book appointment",
        "My appointments",
        "Cancel appointment",
        "Reschedule appointment",
        "Change password",
        "Logout"
    };
    for (;;) {
        int pick = ui_menu("Patient Dashboard", "Use arrows; ESC also goes back.", items, (int)(sizeof(items)/sizeof(items[0])));
        if (pick < 0 || pick == 8) return;

        ui_cls();
        printf("%sUser:%s %s\n", C_DIM(), C_RESET(), me->username);
        printf("%sDoctors:%s %d  %sAppointments:%s %d\n\n", C_DIM(), C_RESET(), db->doctors_n, C_DIM(), C_RESET(), db->appts_n);

        if (pick == 0) { list_doctors(db); ui_pause(); }
        else if (pick == 1) { search_doctors(db); ui_pause(); }
        else if (pick == 2) {
            list_doctors(db);
            int doc_id = input_int("Doctor ID: ", 1, 1000000);
            Doctor *doc = find_doctor_by_id(db, doc_id);
            if (!doc) { ui_err("No such doctor."); ui_pause(); continue; }
            char date[32];
            input_line("Date (YYYY-MM-DD): ", date, sizeof(date));
            int Y,M,D;
            if (!parse_yyyy_mm_dd(date, &Y,&M,&D)) { ui_err("Invalid date."); ui_pause(); continue; }
            show_doctor_day_slots(db, doc, Y,M,D, 1);
            ui_pause();
        }
        else if (pick == 3) { patient_book(db, me->profile_id); ui_pause(); }
        else if (pick == 4) { list_patient_appts(db, me->profile_id, 0); ui_pause(); }
        else if (pick == 5) { patient_cancel(db, me->profile_id); ui_pause(); }
        else if (pick == 6) { patient_reschedule(db, me->profile_id); ui_pause(); }
        else if (pick == 7) { ui_change_password(db, me); ui_pause(); }
    }
}

static void dashboard_doctor(DB *db, User *me) {
    const char *items[] = {
        "Today's appointments",
        "All appointments",
        "My patients",
        "Mark appointment status + note",
        "Update work hours / slot",
        "Change password",
        "Logout"
    };
    for (;;) {
        int pick = ui_menu("Doctor Dashboard", "Use arrows; ESC also goes back.", items, (int)(sizeof(items)/sizeof(items[0])));
        if (pick < 0 || pick == 6) return;

        ui_cls();
        Doctor *d = find_doctor_by_id(db, me->profile_id);
        printf("%sUser:%s %s\n", C_DIM(), C_RESET(), me->username);
        if (d) printf("%sDoctor:%s %s (%s)\n\n", C_DIM(), C_RESET(), d->name, d->specialty);

        if (pick == 0) { list_doctor_appts(db, me->profile_id, 1); ui_pause(); }
        else if (pick == 1) { list_doctor_appts(db, me->profile_id, 0); ui_pause(); }
        else if (pick == 2) { doctor_list_patients(db, me->profile_id); ui_pause(); }
        else if (pick == 3) { doctor_mark_status(db, me->profile_id); ui_pause(); }
        else if (pick == 4) { doctor_update_schedule(db, me->profile_id); ui_pause(); }
        else if (pick == 5) { ui_change_password(db, me); ui_pause(); }
    }
}

static void dashboard_admin(DB *db, User *me) {
    const char *items[] = {
        "Create doctor account",
        "List users",
        "List doctors",
        "List all appointments",
        "Change admin password",
        "Logout"
    };
    for (;;) {
        int pick = ui_menu("Admin Dashboard", "Use arrows; ESC also goes back.", items, (int)(sizeof(items)/sizeof(items[0])));
        if (pick < 0 || pick == 5) return;

        ui_cls();
        printf("%sUser:%s %s\n\n", C_DIM(), C_RESET(), me->username);

        if (pick == 0) { admin_create_doctor(db); ui_pause(); }
        else if (pick == 1) { admin_list_users(db); ui_pause(); }
        else if (pick == 2) { list_doctors(db); ui_pause(); }
        else if (pick == 3) { admin_list_appts(db); ui_pause(); }
        else if (pick == 4) { ui_change_password(db, me); ui_pause(); }
    }
}

void app_main_menu(DB *db) {
    ui_enable_vt_utf8();

    const char *items[] = { "Login", "Register (Patient)", "Exit" };
    for (;;) {
        int pick = ui_menu("Welcome", "Tip: you can run by double-clicking telemed.exe", items, 3);
        if (pick < 0 || pick == 2) return;

        ui_cls();
        if (pick == 1) {
            printf("%sRegister patient%s\n\n", C_BOLD(), C_RESET());
            ui_register_patient(db);
            ui_pause();
            continue;
        }

        printf("%sLogin%s\n\n", C_BOLD(), C_RESET());
        User *me = ui_login(db);
        ui_pause();
        if (!me) continue;

        if (me->role == ROLE_ADMIN) dashboard_admin(db, me);
        else if (me->role == ROLE_DOCTOR) dashboard_doctor(db, me);
        else if (me->role == ROLE_PATIENT) dashboard_patient(db, me);
        else { ui_err("Unknown role."); ui_pause(); }
    }
}
